from typing import Dict
import time

class DeviceStore:
    def __init__(self):
        self.devices: Dict[str, dict] = {}
        self.ip_to_agent: Dict[str, str] = {}   # 🔗 IP → agent_id

    def _make_key(self, agent_id=None, mac=None, ip=None):
        if agent_id:
            return f"agent:{agent_id}"
        if mac:
            return f"mac:{mac}"
        return f"ip:{ip}"

    def register(self, *, agent_id=None, mac=None, ip=None):
        key = self._make_key(agent_id, mac, ip)
        now = time.time()

        if key not in self.devices:
            self.devices[key] = {
                "key": key,
                "agent_id": agent_id,
                "mac": mac,
                "ip": ip,
                "status": "online",
                "last_seen": now,
                "linked_agent": None
            }
        else:
            self.devices[key]["last_seen"] = now
            self.devices[key]["status"] = "online"
            if ip:
                self.devices[key]["ip"] = ip

        # 🔗 LINK IP ↔ AGENT (permanent fix)
        if agent_id and ip:
            self.ip_to_agent[ip] = agent_id

            # back-link IP device if it exists
            ip_key = f"ip:{ip}"
            if ip_key in self.devices:
                self.devices[ip_key]["linked_agent"] = agent_id

        return self.devices[key]

    def heartbeat(self, agent_id: str, ip: str | None = None):
        key = f"agent:{agent_id}"
        if key in self.devices:
            self.devices[key]["last_seen"] = time.time()
            self.devices[key]["status"] = "online"
            if ip:
                self.devices[key]["ip"] = ip
                self.ip_to_agent[ip] = agent_id

    def resolve(self, key: str):
        """
        SOC-safe resolution:
        - If SOC opens ip:X → resolve to agent:Y if linked
        - Otherwise return original device
        """
        if key.startswith("ip:"):
            ip = key.replace("ip:", "")
            agent_id = self.ip_to_agent.get(ip)
            if agent_id:
                return self.devices.get(f"agent:{agent_id}")
        return self.devices.get(key)

    def all(self):
        now = time.time()
        for d in self.devices.values():
            age = now - d["last_seen"]
            if age > 90:
                d["status"] = "offline"
            elif age > 30:
                d["status"] = "stale"
            else:
                d["status"] = "online"
        return list(self.devices.values())

    def get(self, key: str):
        return self.devices.get(key)


device_store = DeviceStore()